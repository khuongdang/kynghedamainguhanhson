<?php
require_once CPAC_DIR . 'classes/third_party/acf.php';
require_once CPAC_DIR . 'classes/third_party/ninja_forms.php';
require_once CPAC_DIR . 'classes/third_party/woocommerce.php';
require_once CPAC_DIR . 'classes/third_party/wpml.php';