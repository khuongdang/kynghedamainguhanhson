# Translate into your own language

Admin Columns can be easily translated into your chosen language. If you don’t have a lot of time, no problem. You can just translate sentences collaborative at Transifex.
 
1. **Go to [Trasifex - Admin Columns](https://www.transifex.com/codepress/admin-columns/)**
2. If you do not have an account yet you can register one for free.
3. Pick your language and start translating.

