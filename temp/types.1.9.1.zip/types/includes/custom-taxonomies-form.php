<?php
/**
 *
 * Custom taxonomies form
 *
 *
 */

/**
 * Add/edit form structure
 */

/**
 * Adds JS validation script.
 */
function wpcf_admin_tax_form_js_validation()
{
    wpcf_form_render_js_validation();
}

